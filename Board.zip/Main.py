#
# create and run game
#
import Game

def main():
    TheGame = Game.Game()
    TheGame.run()

if __name__ == "__main__":
    main()